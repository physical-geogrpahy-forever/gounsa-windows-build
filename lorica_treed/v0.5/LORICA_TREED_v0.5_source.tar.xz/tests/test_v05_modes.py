from pathlib import Path
root=Path(__file__).resolve().parents[1]
phys=(root/'TREED/src/TREED_physiological_functions.jl').read_text()
pars=(root/'TREED/src/TREED_pars.jl').read_text()
driver=(root/'coupling/treed_lorica_driver.jl').read_text()
cs=(root/'LORICA/Functions/treed_coupling.cs').read_text()
assert 'root_allocation_mode = "adaptive_experimental"' in pars
assert 'allocation_mode == "fixed_original"' in phys
assert 'allocation_mode == "adaptive_experimental"' in phys
assert 'x0 = [1.0, 500, 1]' in phys
assert 'x0 = [1.0, 500, 1, par.r_s_r_initial]' in phys
assert 'new_r_s_r = par.r_s_r_initial' in phys
assert 'root_allocation_mode=allocation_mode' in driver
assert 'treed_rootcohesion_summary.csv' in cs
assert 'TREED_rootcohesion_timeseries.csv' in cs
for fn in (root/'coupling/scenarios').glob('*.cfg'):
    txt=fn.read_text()
    assert 'root_allocation_mode=' in txt and 'hwang_root_cohesion_reduction_factor=' in txt
print('V0.5 MODE/AUDIT TESTS: PASS')
