import math

# Mirrors the explicit provisional PAW/root term in TREED v0.5.
def water_supply(precip_m_day, paw_mm, rsr, halfsat=1.0, strength=1.0, release_days=365.0, emax=5.0):
    root_access = rsr / (rsr + halfsat)
    paw_buffer = strength * root_access * paw_mm / release_days
    return min(emax, precip_m_day * 1000.0 + paw_buffer)

# 1) No PAW -> exact original precipitation-only supply.
for p in [0.0, 0.001, 0.004, 0.01]:
    expected=min(5.0,p*1000.0)
    got=water_supply(p,0.0,1.0)
    assert abs(got-expected)<1e-12,(p,got,expected)

# 2) Coupling strength zero -> exact original behaviour even with soil water.
for rsr in [0.25,1.0,4.0]:
    got=water_supply(0.001,200.0,rsr,strength=0.0)
    assert abs(got-1.0)<1e-12

# 3) More root allocation -> greater (bounded) PAW access when not Emax-limited.
vals=[water_supply(0.0,200.0,r) for r in [0.25,1.0,4.0]]
assert vals[0] < vals[1] < vals[2], vals
assert all(0 <= x <= 5.0 for x in vals)

# 4) Deeper/wetter profile (larger PAW capacity) -> greater supply at fixed root allocation.
assert water_supply(0.0,50.0,1.0) < water_supply(0.0,200.0,1.0)

# 5) LORICA daily->monthly precipitation aggregation is conservative.
month=[31,28,31,30,31,30,31,31,30,31,30,31]
# synthetic one mm/day year
Py=[0.001]*365
monthly=[]; i=0
for nd in month:
    monthly.append(sum(Py[i:i+nd])*1000.0); i+=nd
assert abs(sum(monthly)-365.0)<1e-10
assert monthly[0]==31.0 and monthly[1]==28.0

print('COUPLING MATH TESTS v0.5: PASS')


# 6) Hwang et al. (2015) Eq. (5) biomass -> root cohesion.
def hwang_root_cohesion_kpa(rootC_gC_m2, fC=0.47, rho=435.3, K=1.2, Tr_MPa=10.0, multiplier=1.0):
    if rootC_gC_m2 <= 0 or fC <= 0 or rho <= 0 or K <= 0 or Tr_MPa <= 0:
        return 0.0
    Br = rootC_gC_m2 / (1000.0 * fC)
    return multiplier * K * (Tr_MPa * 1e6) * (Br / rho) / 1000.0

# 470 gC m-2 = 1 kg dry-root biomass m-2 at fC=0.47.
expected = 1.2 * 10_000.0 / 435.3  # kPa
got = hwang_root_cohesion_kpa(470.0)
assert abs(got - expected) < 1e-12, (got, expected)
assert hwang_root_cohesion_kpa(0.0) == 0.0
assert abs(hwang_root_cohesion_kpa(940.0) - 2.0 * got) < 1e-12
assert abs(hwang_root_cohesion_kpa(470.0, multiplier=0.5) - 0.5 * got) < 1e-12

print('HWANG ROOT-COHESION TESTS v0.5: PASS')

# 7) Korean species tensile-strength profiles used in v0.4.
kgfcm2_to_mpa = 0.0980665
profiles = {
    "pinus_densiflora_oh2011": 176.25 * kgfcm2_to_mpa,
    "pinus_koraiensis_oh2011": 165.38 * kgfcm2_to_mpa,
    "larix_kaempferi_oh2011": 172.78 * kgfcm2_to_mpa,
    "quercus_mongolica_oh2011": 224.19 * kgfcm2_to_mpa,
    "alnus_japonica_oh2011": 214.29 * kgfcm2_to_mpa,
}
assert abs(profiles["pinus_densiflora_oh2011"] - 17.284220625) < 1e-10
assert profiles["quercus_mongolica_oh2011"] > profiles["pinus_densiflora_oh2011"]

# 8) Explicit reduction factor is linear and can represent the 0.20-0.67
# sensitivity bracket implied by 1.5-5.1x Wu/direct-shear overprediction.
raw = hwang_root_cohesion_kpa(470.0, Tr_MPa=profiles["pinus_densiflora_oh2011"])
for red in [0.20, 0.40, 0.67, 1.0]:
    corrected = red * raw
    assert abs(corrected/raw - red) < 1e-12

print('KOREAN ROOT-STRENGTH PROFILE TESTS v0.5: PASS')
