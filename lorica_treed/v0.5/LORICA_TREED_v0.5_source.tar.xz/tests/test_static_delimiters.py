from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'LORICA/Functions/treed_coupling.cs').read_text(errors='ignore')
# Strip block comments, line comments, verbatim/regular strings approximately.
x=re.sub(r'/\*.*?\*/','',text,flags=re.S)
x=re.sub(r'//.*','',x)
x=re.sub(r'@"(?:""|[^"])*"','""',x)
x=re.sub(r'"(?:\\.|[^"\\])*"','""',x)
for op,cl,name in [('{','}','brace'),('(',')','paren'),('[',']','bracket')]:
    bal=0
    for ch in x:
        if ch==op: bal+=1
        elif ch==cl:
            bal-=1
            assert bal>=0, f'unmatched closing {name}'
    assert bal==0, f'unbalanced {name}: {bal}'
print('STATIC DELIMITER AUDIT v0.5: PASS')
