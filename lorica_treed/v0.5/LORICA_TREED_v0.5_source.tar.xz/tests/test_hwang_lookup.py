from pathlib import Path
import csv, subprocess, sys
root=Path(__file__).resolve().parents[1]
subprocess.check_call([sys.executable, str(root/'coupling/audit_hwang_cohesion.py')])
p=root/'coupling/HWANG_COHESION_LOOKUP.csv'
rows=list(csv.DictReader(p.open()))
assert rows
# Hwang conversion must be linear in the explicit reduction factor.
sel=[r for r in rows if r['profile']=='pinus_densiflora_oh2011' and r['rootC_gC_m2']=='500']
vals={float(r['reduction_factor']):float(r['Cr_kPa']) for r in sel}
assert abs(vals[0.40]/vals[1.0]-0.40)<1e-12
assert abs(vals[0.20]/vals[1.0]-0.20)<1e-12
# Raw 500 gC m-2 should be ~50.69 kPa for the configured P. densiflora profile.
assert abs(vals[1.0]-50.689093728463135)<1e-9
print('HWANG LOOKUP TESTS v0.5: PASS')
