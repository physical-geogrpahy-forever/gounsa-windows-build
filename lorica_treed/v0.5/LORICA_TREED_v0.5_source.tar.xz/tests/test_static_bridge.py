from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]

def check(cond,msg):
    if not cond: raise AssertionError(msg)

for rel in [
    'LORICA/Functions/treed_coupling.cs',
    'TREED/src/TREEDlocalstep.jl',
    'coupling/treed_lorica_driver.jl',
    'coupling/TREED_coupling.cfg',
    'coupling/TREED_radiation_monthly_TEMPLATE.csv',
]: check((ROOT/rel).is_file(), f'missing {rel}')

main=(ROOT/'LORICA/LORICA_main.cs').read_text(errors='ignore')
hydro=(ROOT/'LORICA/Functions/hydro.cs').read_text(errors='ignore')
coup=(ROOT/'LORICA/Functions/treed_coupling.cs').read_text(errors='ignore')
phys=(ROOT/'TREED/src/TREED_physiological_functions.jl').read_text()
model=(ROOT/'TREED/src/TREED_model_functions.jl').read_text()
local=(ROOT/'TREED/src/TREEDlocalstep.jl').read_text()
drv=(ROOT/'coupling/treed_lorica_driver.jl').read_text()

# LORICA call order: coupled TREED before same-year hydrology.
pos_treed=main.index('run_treed_coupling();')
pos_water=main.index('water_balance();', pos_treed)
check(pos_treed < pos_water, 'TREED must run before coupled same-year water balance')
check('prepare_daily_weather_for_current_timestep();' in main, 'same-year weather preparation hook missing')
check('daily_weather_prepared_for_timestep = false' in main, 'weather-prepared flag not reset each year')
check('prepare_daily_weather_for_current_timestep(); // same weather already used by TREED if coupled' in hydro,
      'water_balance does not reuse prepared weather')

# C# project inclusion.
proj=(ROOT/'LORICA/LORICA_2026.csproj').read_text(errors='ignore')
check('Functions\\treed_coupling.cs' in proj,'C# project does not include coupling source')

# Same-year climate aggregation is generated in LORICA.
check('write_treed_same_year_monthly_climate' in coup, 'same-year climate writer missing')
check('Tavgy[day0 + d]' in coup and 'Py[day0 + d]' in coup, 'LORICA daily T/P not aggregated for TREED')
check('treed_climate_monthly.csv' in coup, 'year-specific TREED climate file missing')
check('veg_correction_factor[r, c]' in coup, 'TREED cover does not feed same-year LORICA ET factor')

# TREED local soil state.
check('paw_mm::Raster' in model and 'soildepth_m::Raster' in model, 'soil state missing from TREED climate container')
check('paw_mm = climate.paw_mm[i, j]' in model or 'paw_mm=climate.paw_mm[i, j]' in model,
      'PAW not passed into TREED cell environment')
check('paw_mm=paw_r' in drv and 'soildepth_m=soildepth_r' in drv, 'driver does not pass local soil rasters')

# Root allocation is no longer hard-coded in optimizer.
check('length(x) >= 4 ? x[4] : par.r_s_r_initial' in phys,
      'fixed/adaptive r_s_r optimizer switch missing')
check('r_s_r_optimized = 1.' not in phys, 'hard-coded optimized r_s_r remains')
check('par.r_s_r_min' in phys and 'par.r_s_r_max' in phys, 'r_s_r bounds missing')
check('paw_buffer_mm_day' in phys and 'root_access' in phys, 'PAW/root water-acquisition coupling missing')

# Driver local-grid guarantees.
check('timestep,' in local,'explicit timestep missing')
check('template_raster' not in local,'local adapter unexpectedly uses global template')
pos_dir=drv.index('treed_dir = abspath(ARGS[2])')
pos_inc=drv.index('include(joinpath(treed_dir')
check(pos_inc>pos_dir,'TREED module included before treed_dir is assigned')
check('treed_rootC_areanorm_gC_m2.asc' in drv,'explicit area-normalized root-C output missing')
check('treed_C_fineroot_gC_individual.asc' in drv and 'treed_C_coarseroot_gC_individual.asc' in drv,
      'raw individual root pools missing from audit output')
check('treed_CA_m2.asc' in drv, 'crown-area audit output missing')

# No fabricated operational radiation file is bundled.
check(not (ROOT/'coupling/TREED_radiation_monthly.csv').exists(),
      'operational radiation file should not be prefilled')


# Hwang et al. (2015) root-biomass -> cohesion implementation.
check('hwang_root_cohesion_kPa' in coup, 'Hwang root-cohesion function missing')
check('hwang_root_density_kg_m3' in coup and '435.3' in coup, 'Hwang root density missing')
check('hwang_K_m_inv' in coup and '1.2' in coup, 'Hwang K missing')
check('hwang_root_carbon_fraction' in coup and '0.47' in coup, 'TREED carbon-to-dry-biomass conversion missing')
check('treed_rootcohesion_Hwang2015_kPa.asc' in coup, 'Hwang root-cohesion audit raster missing')

check('hwang_root_tensile_strength_MPa' in coup, 'Korean tensile-strength profile function missing')
check('hwang_root_cohesion_raw_kPa' in coup, 'Raw Hwang root-cohesion function missing')
check('hwang_root_cohesion_reduction_factor' in coup, 'Explicit root-cohesion reduction factor missing')
check('treed_rootcohesion_Hwang2015_raw_kPa.asc' in coup, 'Raw Hwang audit raster missing')
print('STATIC BRIDGE TESTS v0.5: PASS')
