﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;

namespace LORICA4
{
    public partial class Mother_form
    {
        // Opt-in coupling: set LORICA_TREED_COUPLING_DIR to a directory that
        // contains TREED_coupling.cfg, TREED_climate_monthly.csv and the Julia driver.
        bool treed_coupling_enabled()
        {
            string dir = Environment.GetEnvironmentVariable("LORICA_TREED_COUPLING_DIR");
            return !String.IsNullOrWhiteSpace(dir) && Directory.Exists(dir) &&
                   File.Exists(Path.Combine(dir, "TREED_coupling.cfg"));
        }

        Dictionary<string, string> read_treed_cfg(string path)
        {
            var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in File.ReadAllLines(path))
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#") || !line.Contains("=")) continue;
                string[] p = line.Split(new char[] { '=' }, 2);
                d[p[0].Trim()] = p[1].Trim();
            }
            return d;
        }

        double cfg_double(Dictionary<string, string> cfg, string key, double fallback)
        {
            string v;
            double x;
            if (cfg.TryGetValue(key, out v) &&
                Double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out x)) return x;
            return fallback;
        }

        string cfg_string(Dictionary<string, string> cfg, string key, string fallback)
        {
            string v;
            if (cfg.TryGetValue(key, out v) && !String.IsNullOrWhiteSpace(v)) return v.Trim();
            return fallback;
        }

        double percentile_sorted(List<double> sorted, double q)
        {
            if (sorted == null || sorted.Count == 0) return Double.NaN;
            q = Math.Max(0.0, Math.Min(1.0, q));
            double pos = q * (sorted.Count - 1);
            int lo = (int)Math.Floor(pos);
            int hi = (int)Math.Ceiling(pos);
            if (lo == hi) return sorted[lo];
            double f = pos - lo;
            return sorted[lo] * (1.0 - f) + sorted[hi] * f;
        }

        void write_treed_root_cohesion_summary(string outputDir, string exchangeRoot, double[,] rootC,
                                                double[,] raw, double[,] corrected,
                                                Dictionary<string, string> cfg, double TrUsed_MPa)
        {
            var rc = new List<double>();
            var rw = new List<double>();
            var cc = new List<double>();
            int above216 = 0;
            for (int r = 0; r < nr; r++)
            {
                for (int c = 0; c < nc; c++)
                {
                    if (dtm[r, c] == nodata_value) continue;
                    double a = rootC[r, c], b = raw[r, c], d = corrected[r, c];
                    if (!Double.IsNaN(a) && !Double.IsInfinity(a)) rc.Add(a);
                    if (!Double.IsNaN(b) && !Double.IsInfinity(b)) rw.Add(b);
                    if (!Double.IsNaN(d) && !Double.IsInfinity(d))
                    {
                        cc.Add(d);
                        // Hwang et al. (2015) report 21.6 kPa as the spatially uniform
                        // Wu-method comparison case. This is an audit benchmark, not a cap.
                        if (d > 21.6) above216++;
                    }
                }
            }
            rc.Sort(); rw.Sort(); cc.Sort();
            Func<List<double>, double> mean = xs => xs.Count == 0 ? Double.NaN : xs.Average();
            string mode = cfg_string(cfg, "root_allocation_mode", "adaptive_experimental");
            double reduction = cfg_double(cfg, "hwang_root_cohesion_reduction_factor", 1.0);
            string header = "year,root_allocation_mode,Tr_MPa,reduction_factor,n_cells,rootC_mean_gC_m2,rootC_p50_gC_m2,rootC_p95_gC_m2,rootC_max_gC_m2,Cr_raw_mean_kPa,Cr_corrected_mean_kPa,Cr_corrected_p50_kPa,Cr_corrected_p95_kPa,Cr_corrected_max_kPa,fraction_Cr_gt_21p6kPa";
            string row = String.Format(CultureInfo.InvariantCulture,
                "{0},{1},{2:R},{3:R},{4},{5:R},{6:R},{7:R},{8:R},{9:R},{10:R},{11:R},{12:R},{13:R},{14:R}",
                t + 1, mode, TrUsed_MPa, reduction, cc.Count,
                mean(rc), percentile_sorted(rc,0.50), percentile_sorted(rc,0.95), rc.Count > 0 ? rc[rc.Count-1] : Double.NaN,
                mean(rw), mean(cc), percentile_sorted(cc,0.50), percentile_sorted(cc,0.95), cc.Count > 0 ? cc[cc.Count-1] : Double.NaN,
                cc.Count > 0 ? (double)above216 / cc.Count : Double.NaN);
            File.WriteAllText(Path.Combine(outputDir, "treed_rootcohesion_summary.csv"), header + Environment.NewLine + row + Environment.NewLine);
            string ts = Path.Combine(exchangeRoot, "TREED_rootcohesion_timeseries.csv");
            bool newFile = !File.Exists(ts);
            using (StreamWriter sw = new StreamWriter(ts, true))
            {
                if (newFile) sw.WriteLine(header);
                sw.WriteLine(row);
            }
        }

        // Hwang et al. (2015), JGR Biogeosciences, Eq. (5):
        // Cr = K * Tr * Br / rho_r.
        // Korean species profiles below provide Tr only; the Hwang biomass-based
        // conversion remains unchanged. Peer-reviewed means are from Oh et al. (2011).
        // 2025 conference values are included as optional sensitivity profiles.
        double hwang_root_tensile_strength_MPa(Dictionary<string, string> cfg)
        {
            string profile;
            if (!cfg.TryGetValue("hwang_root_tensile_profile", out profile)) profile = "manual";
            profile = profile.Trim().ToLowerInvariant();

            // Oh et al. (2011), Korean Journal of Environment and Ecology 25(1):31-36.
            // kgf cm-2 converted with 1 kgf cm-2 = 0.0980665 MPa.
            if (profile == "pinus_densiflora_oh2011") return 176.25 * 0.0980665;
            if (profile == "pinus_koraiensis_oh2011") return 165.38 * 0.0980665;
            if (profile == "larix_kaempferi_oh2011" || profile == "larix_leptolepis_oh2011") return 172.78 * 0.0980665;
            if (profile == "quercus_mongolica_oh2011") return 224.19 * 0.0980665;
            if (profile == "alnus_japonica_oh2011") return 214.29 * 0.0980665;

            // Kim et al. (2025), KSFE-FETEC conference; use only as a sensitivity profile.
            if (profile == "pinus_densiflora_kim2025") return 15.9;
            if (profile == "pinus_koraiensis_kim2025") return 15.0;
            if (profile == "larix_kaempferi_kim2025") return 20.2;
            if (profile == "quercus_mongolica_kim2025") return 22.2;

            return cfg_double(cfg, "hwang_root_tensile_strength_MPa", 17.284220625);
        }

        double hwang_root_cohesion_raw_kPa(double rootC_gC_m2, Dictionary<string, string> cfg)
        {
            double fC = cfg_double(cfg, "hwang_root_carbon_fraction", 0.47);
            double rhoRoot = cfg_double(cfg, "hwang_root_density_kg_m3", 435.3);
            double K = cfg_double(cfg, "hwang_K_m_inv", 1.2);
            double Tr_MPa = hwang_root_tensile_strength_MPa(cfg);

            if (rootC_gC_m2 <= 0.0 || fC <= 0.0 || rhoRoot <= 0.0 || K <= 0.0 || Tr_MPa <= 0.0) return 0.0;

            // Br [kg DM m-2] = rootC [g C m-2] / 1000 / fC
            double Br_kgDM_m2 = rootC_gC_m2 / (1000.0 * fC);
            // Tr [Pa] = Tr_MPa * 1e6; Cr [kPa] = Cr [Pa] / 1000.
            return Math.Max(0.0, K * (Tr_MPa * 1.0e6) * (Br_kgDM_m2 / rhoRoot) / 1000.0);
        }

        double hwang_root_cohesion_kPa(double rootC_gC_m2, Dictionary<string, string> cfg)
        {
            double reduction = cfg_double(cfg, "hwang_root_cohesion_reduction_factor", 1.0);
            double multiplier = cfg_double(cfg, "hwang_root_cohesion_multiplier", 1.0);
            reduction = Math.Max(0.0, reduction);
            multiplier = Math.Max(0.0, multiplier);
            return reduction * multiplier * hwang_root_cohesion_raw_kPa(rootC_gC_m2, cfg);
        }

        string cfg_path(Dictionary<string, string> cfg, string key, string fallback, string baseDir)
        {
            string v;
            string p = cfg.TryGetValue(key, out v) ? v : fallback;
            if (!Path.IsPathRooted(p)) p = Path.GetFullPath(Path.Combine(baseDir, p));
            return p;
        }

        // Plant-available-water capacity (mm) based on the same Saxton & Rawls
        // theta33/theta1500 equations already used elsewhere in LORICA.
        double treed_paw_mm(int r, int c)
        {
            double paw_m = 0.0;
            for (int lay = 0; lay < max_soil_layers; lay++)
            {
                double h = layerthickness_m[r, c, lay];
                if (h <= 0) continue;
                double sand = texture_kg[r, c, lay, 1];
                double silt = texture_kg[r, c, lay, 2];
                double clay = texture_kg[r, c, lay, 3] + texture_kg[r, c, lay, 4];
                double om = old_SOM_kg[r, c, lay] + young_SOM_kg[r, c, lay];
                double fine = sand + silt + clay;
                if (fine <= 0) continue;
                double S = sand / fine;
                double C = clay / fine;
                double OM = (fine + om > 0) ? 100.0 * om / (fine + om) : 0.0;
                double theta33t = -0.251 * S + 0.195 * C + 0.011 * OM
                                + 0.006 * S * OM - 0.027 * C * OM
                                + 0.452 * S * C + 0.299;
                double theta33 = theta33t + (1.283 * theta33t * theta33t - 0.374 * theta33t - 0.015);
                double theta1500t = -0.024 * S + 0.487 * C + 0.006 * OM
                                  + 0.005 * S * OM - 0.013 * C * OM
                                  + 0.068 * S * C + 0.031;
                double theta1500 = theta1500t + (0.14 * theta1500t - 0.02);
                double available = Math.Max(0.0, theta33 - theta1500);
                paw_m += available * h;
            }
            return paw_m * 1000.0;
        }

        double[] treed_read_monthly_column(string path, int columnIndex, double fallback)
        {
            double[] outv = Enumerable.Repeat(fallback, 12).ToArray();
            if (!File.Exists(path)) return outv;
            string[] lines = File.ReadAllLines(path);
            int m = 0;
            foreach (string raw in lines)
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#") || line.ToLowerInvariant().StartsWith("month")) continue;
                string[] p = line.Split(',');
                if (p.Length <= columnIndex || m >= 12) continue;
                double x;
                if (Double.TryParse(p[columnIndex].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out x)) outv[m] = x;
                m++;
            }
            return outv;
        }

        void write_treed_same_year_monthly_climate(string outputPath, Dictionary<string, string> cfg, string couplingDir)
        {
            // Py is metres/day and Tavgy is degC; both are the exact daily series
            // selected/scaled by LORICA for this model year.
            string radiationFile = Path.Combine(couplingDir, "TREED_radiation_monthly.csv");
            double defaultClt = cfg_double(cfg, "clt_fraction_default", 0.5);
            double defaultRsds = cfg_double(cfg, "rsds_W_m2_default", 150.0);
            double[] clt = treed_read_monthly_column(radiationFile, 1, defaultClt);
            double[] rsds = treed_read_monthly_column(radiationFile, 2, defaultRsds);
            using (StreamWriter sw = new StreamWriter(outputPath, false))
            {
                sw.WriteLine("month,tair_C,precip_mm_month,clt_fraction,rsds_W_m2");
                int day0 = 0;
                for (int mo = 0; mo < 12; mo++)
                {
                    double tsum = 0.0, psum_m = 0.0;
                    for (int d = 0; d < month[mo]; d++)
                    {
                        tsum += Tavgy[day0 + d];
                        psum_m += Py[day0 + d];
                    }
                    double tmean = tsum / month[mo];
                    double pmm = psum_m * 1000.0;
                    sw.WriteLine(String.Format(CultureInfo.InvariantCulture,
                        "{0},{1:R},{2:R},{3:R},{4:R}", mo + 1, tmean, pmm, clt[mo], rsds[mo]));
                    day0 += month[mo];
                }
            }
        }

        void run_treed_coupling()
        {
            string couplingDir = Environment.GetEnvironmentVariable("LORICA_TREED_COUPLING_DIR");
            prepare_daily_weather_for_current_timestep();
            string cfgFile = Path.Combine(couplingDir, "TREED_coupling.cfg");
            var cfg = read_treed_cfg(cfgFile);
            string juliaExe = cfg_path(cfg, "julia_exe", "julia", couplingDir);
            // If julia is a command on PATH, do not force it into an absolute path.
            if (cfg.ContainsKey("julia_exe") && !cfg["julia_exe"].Contains("\\") && !cfg["julia_exe"].Contains("/")) juliaExe = cfg["julia_exe"];
            string treedDir = cfg_path(cfg, "treed_project_dir", "../TREED", couplingDir);
            string driver = cfg_path(cfg, "driver_path", "treed_lorica_driver.jl", couplingDir);

            string exchangeRoot = Path.Combine(workdir, "TREED_exchange_run_" + run_number);
            string yearDir = Path.Combine(exchangeRoot, (t + 1).ToString("D4"));
            string inputDir = Path.Combine(yearDir, "input");
            string outputDir = Path.Combine(yearDir, "output");
            Directory.CreateDirectory(inputDir);
            Directory.CreateDirectory(outputDir);

            out_double(Path.Combine(inputDir, "dtm.asc"), dtm);
            out_double(Path.Combine(inputDir, "soildepth.asc"), soildepth_m);
            double[,] paw = new double[nr, nc];
            for (int r = 0; r < nr; r++)
                for (int c = 0; c < nc; c++)
                    paw[r, c] = (dtm[r, c] == nodata_value) ? nodata_value : treed_paw_mm(r, c);
            out_double(Path.Combine(inputDir, "paw_mm.asc"), paw);

            // Temperature and precipitation come from the exact LORICA daily
            // weather selected/scaled for this year. Cloud/radiation are read
            // from TREED_radiation_monthly.csv (or explicit cfg fallbacks).
            write_treed_same_year_monthly_climate(Path.Combine(inputDir, "treed_climate_monthly.csv"), cfg, couplingDir);
            File.Copy(cfgFile, Path.Combine(exchangeRoot, "TREED_coupling.cfg"), true);

            var psi = new ProcessStartInfo();
            psi.FileName = juliaExe;
            psi.Arguments = "--project=\"" + treedDir + "\" \"" + driver + "\" \"" + yearDir + "\" \"" + treedDir + "\"";
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            using (Process p = Process.Start(psi))
            {
                string stdout = p.StandardOutput.ReadToEnd();
                string stderr = p.StandardError.ReadToEnd();
                p.WaitForExit();
                Debug.WriteLine(stdout);
                if (p.ExitCode != 0) throw new Exception("TREED Julia step failed: " + stderr);
            }

            double[,] fpc = new double[nr, nc];
            double[,] lai = new double[nr, nc];
            double[,] rootC = new double[nr, nc];
            read_double(Path.Combine(outputDir, "treed_fpc.asc"), fpc);
            read_double(Path.Combine(outputDir, "treed_lai.asc"), lai);
            string rootAreaNormFile = Path.Combine(outputDir, "treed_rootC_areanorm_gC_m2.asc");
            if (!File.Exists(rootAreaNormFile)) rootAreaNormFile = Path.Combine(outputDir, "treed_rootC_gC_m2.asc");
            read_double(rootAreaNormFile, rootC);
            if (aridity_vegetation == null || aridity_vegetation.GetLength(0) != nr || aridity_vegetation.GetLength(1) != nc)
                aridity_vegetation = new double[nr, nc];

            double rootCarbonFraction = cfg_double(cfg, "hwang_root_carbon_fraction", 0.47);
            double etBare = cfg_double(cfg, "treed_et_factor_bare", 1.0);
            double etFull = cfg_double(cfg, "treed_et_factor_full_cover", 0.85);
            double[,] rootDryBiomass = new double[nr, nc];
            double[,] rootCohesionRaw = new double[nr, nc];
            double[,] rootCohesion = new double[nr, nc];
            double TrUsed_MPa = hwang_root_tensile_strength_MPa(cfg);
            for (int r = 0; r < nr; r++)
            {
                for (int c = 0; c < nc; c++)
                {
                    if (dtm[r, c] == nodata_value) continue;
                    double cover = Math.Max(0.0, Math.Min(1.0, fpc[r, c]));
                    aridity_vegetation[r, c] = cover;
                    // Interpolate the existing LORICA ET correction between bare
                    // ground and full vegetation cover. TREED therefore affects
                    // the same year's water balance when coupling is enabled.
                    veg_correction_factor[r, c] = etBare + cover * (etFull - etBare);
                    // TREED replaces LORICA's native land-use root cohesion using
                    // Hwang et al. (2015) Eq. (5): Cr = K * Tr * Br / rho_r.
                    double rc = Math.Max(0.0, rootC[r, c]);
                    rootDryBiomass[r, c] = (rootCarbonFraction > 0.0) ? rc / (1000.0 * rootCarbonFraction) : 0.0;
                    rootCohesionRaw[r, c] = hwang_root_cohesion_raw_kPa(rc, cfg);
                    rootCohesion[r, c] = hwang_root_cohesion_kPa(rc, cfg);
                    root_cohesion_kPa_new[r, c] = rootCohesion[r, c];
                }
            }
            // Audit rasters make the Hwang conversion fully traceable for every year.
            out_double(Path.Combine(outputDir, "treed_root_biomass_kgDM_m2.asc"), rootDryBiomass);
            out_double(Path.Combine(outputDir, "treed_rootcohesion_Hwang2015_raw_kPa.asc"), rootCohesionRaw);
            out_double(Path.Combine(outputDir, "treed_rootcohesion_Hwang2015_kPa.asc"), rootCohesion);
            File.WriteAllText(Path.Combine(outputDir, "treed_rootcohesion_parameters.txt"),
                "Tr_used_MPa=" + TrUsed_MPa.ToString("R", CultureInfo.InvariantCulture) + Environment.NewLine +
                "reduction_factor=" + cfg_double(cfg, "hwang_root_cohesion_reduction_factor", 1.0).ToString("R", CultureInfo.InvariantCulture) + Environment.NewLine +
                "rho_root_kg_m3=" + cfg_double(cfg, "hwang_root_density_kg_m3", 435.3).ToString("R", CultureInfo.InvariantCulture) + Environment.NewLine +
                "K_m_inv=" + cfg_double(cfg, "hwang_K_m_inv", 1.2).ToString("R", CultureInfo.InvariantCulture) + Environment.NewLine +
                "root_allocation_mode=" + cfg_string(cfg, "root_allocation_mode", "adaptive_experimental") + Environment.NewLine +
                "soil_water_coupling_strength=" + cfg_double(cfg, "soil_water_coupling_strength", 1.0).ToString("R", CultureInfo.InvariantCulture) + Environment.NewLine);
            write_treed_root_cohesion_summary(outputDir, exchangeRoot, rootC, rootCohesionRaw, rootCohesion, cfg, TrUsed_MPa);
            Debug.WriteLine("TREED coupling applied for model year " + (t + 1) + "; Hwang Tr=" + TrUsed_MPa + " MPa; allocation mode=" + cfg_string(cfg, "root_allocation_mode", "adaptive_experimental"));
        }
    }
}
