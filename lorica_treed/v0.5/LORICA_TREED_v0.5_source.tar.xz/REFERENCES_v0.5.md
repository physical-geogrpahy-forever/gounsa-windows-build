# LORICA–TREED v0.5 coupling references

## TREED model definition

Rogger, J., et al. (2026). TREED (v1.0): a trait- and optimality-based eco-evolutionary vegetation model for the deep past and the present. *Geoscientific Model Development*, 19, 4931–4960. https://doi.org/10.5194/gmd-19-4931-2026

TREED treats each grid cell as a community-representative average plant rather than resolving individual populations. `C_leaf` and coarse-root carbon are individual-scale carbon pools. TREED normalizes relevant carbon costs/fluxes by crown area (`CA`). v0.5 uses the same normalization for the Hwang coupling and retains both individual pools and the area-normalized output.

## Root biomass -> cohesion

Hwang, T., Band, L. E., Hales, T. C., Miniat, C. F., Vose, J. M., Bolstad, P. V., Miles, B., & Price, K. (2015). Simulating vegetation controls on hurricane-induced shallow landslides with a distributed ecohydrological model. *Journal of Geophysical Research: Biogeosciences*, 120, 361–378. https://doi.org/10.1002/2014JG002824

Implemented Eq. (5): `Cr = K * Tr * Br / rho_r`. Hwang uses `K=1.2`; measured mean root density was `rho_r=435.3 kg m-3`.

For Korean tensile-strength profiles and reduction-factor sensitivity, see `REFERENCES_v0.4.md`; v0.5 does not alter those source values.
