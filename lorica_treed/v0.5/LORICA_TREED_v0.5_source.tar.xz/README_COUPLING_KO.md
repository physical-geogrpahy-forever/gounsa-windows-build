# LORICA + TREED coupling v0.5

## 이번 버전에서 닫힌 feedback

v0.5은 v0.1의 단순 파일 왕복에서 한 단계 더 나아가 다음 연간 양방향 feedback을 실제 코드에 연결한다.

```text
LORICA current soil/profile
  -> soil depth + PAW
LORICA same-year daily weather
  -> monthly T/P for TREED
  -> TREED optimizes/evolves vegetation including r_s_r
  -> FPC / LAI / root C
  -> same-year LORICA ET / runoff erosion / landslide root-cohesion interface
  -> changed soil depth / DEM
  -> next year
```

## 1. 같은 해 기후 단일화

LORICA가 선택하고 기후변화 시나리오로 rescale한 `Py[365]`, `Tavgy[365]`를 TREED 호출 전에 준비한다. 이를 월별 평균기온과 월강수량으로 집계하여 각 연도 exchange 폴더의

`input/treed_climate_monthly.csv`

로 쓴다. 따라서 TREED와 LORICA의 연도별 온도/강수 forcing은 동일하다.

LORICA에는 cloud fraction/shortwave radiation 일자료가 없으므로 이 두 열만 `coupling/TREED_radiation_monthly.csv`의 월 climatology를 쓴다. 제공된 `TREED_radiation_monthly_TEMPLATE.csv`를 복사/작성해야 한다. 파일이 없거나 값이 비어 있으면 cfg의 fallback을 쓰지만, production run에서는 실제 값을 넣는 것을 권장한다.

## 2. 실행 순서 수정

coupling ON일 때 TREED를 `water_balance()`보다 먼저 실행한다. `water_balance()`는 이미 준비된 동일한 일별 weather를 재사용한다. TREED FPC는 같은 해에

- LORICA 유수침식의 vegetation-cover fraction
- LORICA ET correction factor

에 즉시 반영된다.

coupling OFF일 때 기존 LORICA vegetation 순서는 그대로 유지한다.

## 3. LORICA -> TREED soil water

LORICA soil layers에서 Saxton & Rawls 계열 식으로 profile PAW capacity [mm]를 계산해 `paw_mm.asc`로 전달한다. soil depth도 별도 raster로 전달한다.

TREED의 원래 water supply는 월평균 강수만 사용했다. v0.5 coupled run에서는 다음의 명시적 provisional term을 추가했다.

```text
root_access = r_s_r / (r_s_r + root_paw_access_halfsat)
paw_buffer_mm_day = soil_water_coupling_strength * root_access * PAW_mm / paw_release_days
Esupply = min(Emax, precip_mm_day + paw_buffer_mm_day)
```

이 식은 **결합 구조를 시험하기 위한 임시 coupling law**이며 원본 TREED 식이 아니다. 모든 계수는 `TREED_coupling.cfg`에서 노출되어 있고, 본실험 전에 문헌 기반/관측 기반 식으로 교체 또는 보정해야 한다.

`soil_water_coupling_strength=0`이면 원래 TREED precipitation-only water supply로 정확히 돌아간다.

## 4. r_s_r 해제

기존 TREED optimizer는 `r_s_r=1`로 고정했다. v0.5에서는 최적화 벡터를

```text
[a_ll, C_leaf, H, r_s_r]
```

로 확장했다. 기본 탐색범위는 0.25–4.0이며 cfg에서 변경할 수 있다. 뿌리 증가는 원본 TREED의 fine/coarse-root respiration 및 turnover 비용을 증가시키고, coupled run에서는 PAW 접근 편익도 증가시킨다.

## 5. TREED -> LORICA

- `FPC` -> `aridity_vegetation`을 0–1 cover fraction으로 사용
- FPC -> 같은 해 `veg_correction_factor`를 bare/full-cover 값 사이에서 선형보간
- `C_fineroot`, `C_coarseroot`는 TREED의 대표개체 기준 g C 값으로 별도 저장
- `CA`도 별도 저장
- `(C_fineroot+C_coarseroot)/CA` -> TREED 내부 면적정규화 관례를 따른 root C [gC m-2]
- root C -> `root_cohesion_kPa_new` 인터페이스

root biomass -> root cohesion은 **Hwang et al. (2015) Eq. (5)** 로 연결한다. TREED의 total root carbon은 dry root biomass로 변환한 뒤 LORICA의 `root_cohesion_kPa_new`에 들어간다.

```text
Br [kg DM m-2] = Croot [g C m-2] / 1000 / fC
Cr [kPa] = K * Tr [Pa] * (Br / rho_r) / 1000
```

기본값은 Hwang의 `K=1.2`, `rho_r=435.3 kg m-3`와 TREED의 dry-biomass carbon fraction `fC=0.47`이다. Hwang 본문은 공간분포 계산에 사용한 `Tr`의 수치 자체를 인쇄하지 않으므로, v0.5에서는 한국 수종별 실측 `Tr` 프로파일을 추가했다. 기본 프로파일은 Oh et al. (2011)의 소나무(Pinus densiflora) 평균 인장강도 176.25 kgf cm-2 = 17.284 MPa이다. 같은 논문에서 잣나무 16.219 MPa, 낙엽송 16.943 MPa, 신갈나무 21.986 MPa, 오리나무 21.013 MPa를 사용할 수 있다. 2025년 국내 측정값(P. densiflora 15.9, P. koraiensis 15.0, L. kaempferi 20.2, Q. mongolica 22.2 MPa)도 민감도 프로파일로 포함한다.

Wu/Waldron 계열은 직접전단시험보다 root cohesion을 크게 산정할 수 있으므로 v0.5는 `hwang_root_cohesion_reduction_factor`를 별도 노출한다. 2025년 국내 측정에서는 Wu 추정치가 직접전단시험보다 1.5-5.1배 컸으므로, 보정 민감도 범위로 약 0.20-0.67을 시험할 수 있다. 기본값 1.0은 Hwang식 자체를 그대로 재현하는 값이며, 보정을 몰래 적용하지 않는다.

## 6. 실행 준비

1. `coupling/TREED_radiation_monthly_TEMPLATE.csv`를 `TREED_radiation_monthly.csv`로 복사하고 12개월 cloud fraction과 incoming shortwave radiation [W m-2]을 입력한다.
2. 환경변수 설정:

```text
LORICA_TREED_COUPLING_DIR=<패키지의 coupling 폴더 절대경로>
```

3. Julia와 TREED Project 환경이 설치되어 있어야 한다.
4. 기존 LORICA 실행을 시작한다. coupling은 환경변수가 있을 때만 켜진다.

## 아직 남은 과학 검증

- 현장 식생조사에 맞춰 `Tr` 수종 프로파일 또는 혼합림 가중 방식을 확정
- PAW-root water acquisition 식의 검증/보정
- LORICA 연누적 water erosion을 실제 강우 event별 지형갱신으로 바꿀지 결정
- TREED FPC/LAI -> ET 계수의 검증
- 실제 LORICA + Julia runtime에서 2x2/10x10 다년 실행 및 mass/state closure

## 런타임 검증 상태

현재 작업환경에는 .NET/Mono/Julia runtime이 없어 C# 및 Julia의 실제 실행/컴파일은 수행하지 못했다. 대신 v0.5 패키지에는 정적 bridge tests, Hwang 단위/선형성 수치시험, 한국 수종별 Tr 프로파일 및 reduction-factor 시험을 포함한다.


## v0.5 검증 모드

새로운 과정은 추가하지 않았다. `root_allocation_mode=fixed_original`은 원 TREED의 `r_s_r=1.0`을 유지하고, `adaptive_experimental`에서만 PAW 접근성과 함께 `r_s_r`을 최적화한다. `coupling/scenarios/`에 두 모드를 분리한 대조군과 Hwang reduction-factor 민감도 설정을 제공한다. 매년 `treed_rootcohesion_summary.csv`와 전체 실행 `TREED_rootcohesion_timeseries.csv`를 기록한다. 21.6 kPa는 Hwang et al. (2015)의 uniform Wu comparison 값일 뿐 상한으로 사용하지 않는다.


## v0.5 root-carbon 단위 감사

TREED v1.0 논문과 소스에서 `C_leaf` 및 coarse-root carbon은 대표 개체당 carbon pool로 정의된다. TREED의 maintenance respiration과 turnover는 이 pool을 crown area `CA`로 나눠 면적당 flux로 환산한다. Hwang 결합도 동일한 정규화를 사용한다. 각 연도 출력에 `treed_C_fineroot_gC_individual.asc`, `treed_C_coarseroot_gC_individual.asc`, `treed_CA_m2.asc`, `treed_rootC_areanorm_gC_m2.asc`를 함께 남겨 이 변환을 역추적할 수 있게 했다.
