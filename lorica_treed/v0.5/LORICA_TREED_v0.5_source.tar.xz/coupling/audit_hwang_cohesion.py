#!/usr/bin/env python3
"""Transparent Hwang et al. (2015) Eq. 5 lookup; no model execution required."""
from pathlib import Path
import csv
K=1.2; rho=435.3; fC=0.47
profiles={
 "pinus_densiflora_oh2011":17.284220625,
 "pinus_koraiensis_oh2011":16.2182,
 "larix_kaempferi_oh2011":16.9439,
 "quercus_mongolica_oh2011":21.9855,
 "alnus_japonica_oh2011":21.0147,
}
rootC=[0,100,250,500,750,1000,1500,2000]
reductions=[1.0,0.67,0.40,0.20]
out=Path(__file__).with_name('HWANG_COHESION_LOOKUP.csv')
with out.open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['profile','Tr_MPa','rootC_gC_m2','root_biomass_kgDM_m2','reduction_factor','Cr_kPa'])
    for name,tr in profiles.items():
        for c in rootC:
            Br=c/(1000*fC)
            raw=K*(tr*1e6)*(Br/rho)/1000 if c>0 else 0.0
            for r in reductions: w.writerow([name,tr,c,Br,r,raw*r])
print(out)
