#!/usr/bin/env python3
from pathlib import Path
import shutil, sys
here=Path(__file__).resolve().parent
if len(sys.argv)!=2:
    print("Usage: python apply_scenario.py scenarios/<file>.cfg")
    raise SystemExit(2)
src=Path(sys.argv[1])
if not src.is_absolute():
    src=(here/src).resolve()
if not src.exists():
    raise SystemExit(f"Not found: {src}")
dst=here/"TREED_coupling.cfg"
shutil.copy2(src,dst)
print(f"Activated {src.name} -> {dst}")
