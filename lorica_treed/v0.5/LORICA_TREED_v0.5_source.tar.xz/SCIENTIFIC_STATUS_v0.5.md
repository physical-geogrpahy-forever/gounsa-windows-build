# LORICA–TREED v0.5 scientific status

## Directly inherited from the original models

- TREED photosynthesis, respiration, allometry, carbon turnover, trait optimization framework, and fine/coarse-root carbon pools.
- LORICA soil profiles, daily hydrology, water erosion/sediment transport, weathering, shallow-landslide initiation/continuation/deposition, and DEM/soil-depth updating.

## Literature-based coupling

- TREED `C_fineroot` and `C_coarseroot` are individual-scale carbon pools. The coupling follows TREED's own flux normalization and divides their sum by crown area `CA`, yielding an area-normalized root C density before conversion to dry belowground biomass with `fC=0.47`.
- This area-normalized model quantity is retained separately from the raw individual pools; it should not be described as a direct field measurement of belowground biomass.
- Belowground biomass is converted to root cohesion with Hwang et al. (2015) Eq. (5), `Cr = K * Tr * Br / rho_r`.
- Hwang values retained directly where available: `K=1.2`, `rho_r=435.3 kg m-3`.
- Korean species tensile-strength profiles are external parameter choices; they do not modify the Hwang equation.

## Experimental extension that is NOT part of original TREED

- LORICA plant-available water (PAW) can add a bounded water-supply term to TREED.
- In `adaptive_experimental` mode, `r_s_r` becomes an optimized trait and controls the accessible PAW fraction.
- Because no published TREED equation defines this exact PAW–`r_s_r` response, its parameters remain explicit sensitivity parameters.
- `fixed_original` mode keeps `r_s_r=1.0` exactly and is the required control.

## Explicit uncertainty, not silently calibrated

- Hwang/Wu raw cohesion is saved separately from corrected cohesion.
- `hwang_root_cohesion_reduction_factor` is never inferred internally. Scenarios 1.00, 0.67, 0.40, and 0.20 are provided for sensitivity analysis.
- The Hwang 21.6 kPa spatially uniform Wu comparison is reported only as an audit benchmark; it is not a cap.

## Not included

- No taproot geometry or root architecture model.
- No additional disturbance module beyond processes already present in TREED/LORICA.
