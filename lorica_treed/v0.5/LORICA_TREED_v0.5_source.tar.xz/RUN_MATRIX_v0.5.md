# LORICA–TREED v0.5 control matrix

No additional process is introduced in v0.5. The purpose is to separate original TREED behaviour from the experimental soil-water/root-allocation feedback and from the Hwang root-cohesion correction uncertainty.

| scenario | r_s_r | LORICA PAW -> TREED | Hwang reduction | purpose |
|---|---|---|---:|---|
| 01 | fixed 1.0 | off | 1.00 | original-TREED physiological control |
| 02 | fixed 1.0 | on | 1.00 | isolate soil-water coupling |
| 03 | adaptive | on | 1.00 | full coupling, raw Hwang Eq. 5 |
| 04 | adaptive | on | 0.67 | root-cohesion sensitivity |
| 05 | adaptive | on | 0.40 | root-cohesion sensitivity |
| 06 | adaptive | on | 0.20 | root-cohesion sensitivity |

`21.6 kPa` in the audit output is only the spatially uniform Wu-method comparison value reported by Hwang et al. (2015). It is **not** used as a cap or calibration target.

Activate a scenario by copying it to `coupling/TREED_coupling.cfg`, or run:

```bash
python coupling/apply_scenario.py scenarios/03_adaptive_root_hwang_raw.cfg
```
