###########################################################
# TREED local-grid coupling helpers for LORICA
# v0.4: local soil-water/root-allocation coupling for LORICA.
###########################################################

"""
Create TREED climate input on an existing local/projected grid without
resampling to the global lon/lat template. `latitude_deg` is used only for
astronomical daylength; all cells share that latitude in v0.4.

Inputs must already be Rasters on identical X/Y grids. `tair` and climate
fluxes have a Ti dimension of length 12; `topo` is 2-D.
Units follow original TREED input conventions:
- tair: K
- precip: m s-1
- clt: 0-1
- rsds: W m-2
- topo: m
"""
function create_TREED_local_climate_input(tair, precip, clt, rsds, topo, paw_mm, soildepth_m, CO2, latitude_deg)
    tair = convert.(Float32, replace_missing(tair, -Inf32)) .- 273.15
    precip = convert.(Float32, replace_missing(precip, -Inf32)) .* (60*60*24)
    clt = convert.(Float32, replace_missing(clt, -Inf32))
    rsds = convert.(Float32, replace_missing(rsds, -Inf32))
    topo = convert.(Float32, replace_missing(topo, -Inf32))
    paw_mm = convert.(Float32, replace_missing(paw_mm, Float32(NaN)))
    soildepth_m = convert.(Float32, replace_missing(soildepth_m, Float32(NaN)))

    albedo = deepcopy(topo)
    albedo[topo .< 0] .= 0.069
    albedo[topo .>= 0] .= 0.15

    rss = deepcopy(rsds)
    rls = deepcopy(rsds)
    b = 0.2; A = 107.0
    for m in 1:12
        rss[Ti=m] .= rsds[Ti=m] .* (1 .- albedo)
        ni = 1 .- clt[Ti=m]
        rls[Ti=m] .= (b .+ (1-b) .* ni) .* (A .- tair[Ti=m])
    end
    rss = rss .* (60*60*24*1e-6)
    rsds = rsds .* (60*60*24*1e-6)
    rls = rls .* (60*60*24*1e-6) .* (-1)

    daylength = deepcopy(precip)
    DOIs = [15,46,73,104,134,166,196,227,259,288,319,349]
    for m in 1:12
        hours = max(1.0, daylength_calculation(latitude_deg, DOIs[m]))
        daylength[Ti=m] .= hours
    end

    habitable = deepcopy(topo)
    habitable .= 1
    habitable[isinf.(tair[:,:,1]) .| isnan.(tair[:,:,1])] .= NaN
    habitable[isinf.(topo) .| isnan.(topo)] .= NaN

    return TREED_climate_input(precip, tair, rsds, rss, rls, daylength,
                               Float64(CO2), habitable, topo, paw_mm, soildepth_m)
end

"""
Local-grid equivalent of TREEDnonsteadystep. `timestep` is explicit (fixes the
undefined global `timestep` dependency in the original coupling-oriented step).
"""
function TREEDlocalstep(; tair, precip, clt, rsds, topo, paw_mm, soildepth_m, CO2, latitude_deg,
                          evorate, dispersal, outputdir, traitdir, timestep,
                          kwargs...)
    pars2 = merge(pars, kwargs)
    climate = create_TREED_local_climate_input(tair, precip, clt, rsds, topo,
                                                paw_mm, soildepth_m, CO2, latitude_deg)
    mkpath(traitdir)
    if !isfile(joinpath(traitdir, "traits_restart.jld2"))
        traits_start = initialize_TREED_traits(climate)
    else
        data = load(joinpath(traitdir, "traits_restart.jld2"))
        traits_start = data["traits_end"]
    end

    traits_optimized = run_TREED_optimization(traits_start, climate, pars2)
    traits_evolved = run_TREED_evolution(traits_start, traits_optimized,
                                         climate, evorate, pars2)
    traits_end = run_TREED_ecology(traits_start, traits_evolved,
                                   traits_optimized, climate, dispersal, pars2)
    @save joinpath(traitdir, "traits_restart.jld2") traits_end

    vegetation_output = run_TREED_final_distribution(traits_end, climate, pars2)
    TREED_output = RasterStack(merge(vegetation_output, (topography=climate.topo,)))
    mkpath(outputdir)
    write(joinpath(outputdir, "TREED_output_timestep_$(timestep).nc"),
          TREED_output, missingval=-Inf32, force=true)
    return TREED_output
end
